This is a home task project for a python course.
Written for 3 last days before the deadline, which was extended.
The part with GUI was written the last, in a very hurry.

It is 3:28 am, hope I'l will wake up tomorrow.